import React from "react";
import {
    View,
    Text,
    StyleSheet,
    Button,
} from "react-native";
import LinearGradient from 'react-native-linear-gradient';
import { color } from '../Assets/color';
import Logo from '../Assets/logo';
import GradientButton from '../Assets/gradientButton';
function Login({ navigation }) {

    return (
        <>
            <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} colors={[color.primaryGreen, color.primaryBlue]} style={styles.container}>
                <Text style={styles.watermarkText}>SMOGBUDDY</Text>
                <View style={{ flex: 1 }}>
                    <Logo />
                </View>
                <View style={styles.button}>
                    <GradientButton/>
                </View>
            </LinearGradient>
        </>
    );

}

export default Login;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent:"center",
    },
    watermarkText: {
        flex: 1,
        fontFamily: 'Montserrat-Bold',
        fontSize: 20,
        color: color.primaryWhite,

    },
    button: {
        flex: 1,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 6,
        },
        shadowOpacity: 1,
        shadowRadius: 8.30,

        elevation: 10,
        margin: 10,


    }
});